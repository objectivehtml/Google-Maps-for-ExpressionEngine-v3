<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang	= array(
	
	'auto_import_module_name'			=> 'Auto Import',
	'auto_import_module_description'	=> 'Automatically import data from multiple .csv on an automated schedule.',
		
	//--------------------------------------------
	'', ''
);