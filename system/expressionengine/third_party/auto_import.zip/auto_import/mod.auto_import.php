<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Auto Import
 * 
 * @package		Auto Import
 * @author		Justin Kimbrell
 * @copyright	Copyright (c) 2012, Objective HTML
 * @link 		http://www.objectivehtml.com
 * @version		0.1.0
 * @build		20120516
 */

class Auto_import {
	
	public function __construct()
	{
		$this->EE =& get_instance();
		
	}
	
}